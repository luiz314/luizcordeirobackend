package com.marketplace.luizcordeiro.models.item;

public interface CartItem {

	public float calculateItemPrice();
}
