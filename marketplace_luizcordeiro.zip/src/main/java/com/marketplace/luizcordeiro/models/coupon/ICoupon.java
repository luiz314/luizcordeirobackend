package com.marketplace.luizcordeiro.models.coupon;

import java.util.List;

import com.marketplace.luizcordeiro.exceptions.EmptyFieldException;
import com.marketplace.luizcordeiro.exceptions.NotFoundException;
import com.marketplace.luizcordeiro.forms.CouponForm;
import com.marketplace.luizcordeiro.models.coupon.CouponImpl;

public interface ICoupon {

	List<CouponImpl> getAll();

	List<CouponImpl> getActivesCoupons();
	
	CouponImpl getById(Long id) throws NotFoundException, EmptyFieldException;
	
	CouponImpl addCoupon(CouponForm couponForm) throws EmptyFieldException;

	CouponImpl updateCoupon(CouponForm couponForm) throws EmptyFieldException, NotFoundException;
	
	void deleteCoupon(Long couponId) throws EmptyFieldException, NotFoundException;

	void reactivateCoupon(Long couponId) throws EmptyFieldException, NotFoundException;
}
