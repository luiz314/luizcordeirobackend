package com.marketplace.luizcordeiro.models.item;

import java.util.List;

import com.marketplace.luizcordeiro.exceptions.EmptyFieldException;
import com.marketplace.luizcordeiro.exceptions.NotFoundException;
import com.marketplace.luizcordeiro.forms.CartItemForm;

public interface IItem {

	CartItemImpl getById(Long itemId) throws NotFoundException, EmptyFieldException;
	
	List<CartItemImpl> findAll();

	CartItemImpl updateItem(Long cartId, CartItemForm itemForm) throws NotFoundException, EmptyFieldException;

	void deleteItem(Long itemId) throws NotFoundException, EmptyFieldException;

	CartItemImpl saveItem(CartItemForm itemForm) throws EmptyFieldException, NotFoundException;
}
