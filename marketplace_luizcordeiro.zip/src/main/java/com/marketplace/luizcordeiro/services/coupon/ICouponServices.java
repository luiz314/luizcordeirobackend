package com.marketplace.luizcordeiro.services.coupon;

import com.marketplace.luizcordeiro.models.coupon.ICoupon;

public interface ICouponServices extends ICoupon {
}
