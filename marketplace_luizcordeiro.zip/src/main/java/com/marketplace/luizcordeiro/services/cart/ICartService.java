package com.marketplace.luizcordeiro.services.cart;

import com.marketplace.luizcordeiro.models.cart.ICart;

public interface ICartService extends ICart {

}
