package com.marketplace.luizcordeiro.services.item;

import com.marketplace.luizcordeiro.models.item.IItem;

public interface IItemService extends IItem {

}
