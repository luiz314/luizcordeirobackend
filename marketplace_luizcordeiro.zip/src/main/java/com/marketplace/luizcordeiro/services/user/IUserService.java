package com.marketplace.luizcordeiro.services.user;

import com.marketplace.luizcordeiro.forms.UserForm;
import com.marketplace.luizcordeiro.models.user.UserImpl;

import java.util.List;

public interface IUserService {


	UserImpl addUser(UserForm userForm);

	UserImpl updateUser(UserForm userForm);

	UserImpl getUser(long id);

	UserImpl getUserByEmail(long email);

	List<UserImpl> getUsers();





}
