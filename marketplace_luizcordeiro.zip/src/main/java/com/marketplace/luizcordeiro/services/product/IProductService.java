package com.marketplace.luizcordeiro.services.product;

import com.marketplace.luizcordeiro.models.product.IProduct;

public interface IProductService extends IProduct {

}
