package com.marketplace.luizcordeiro.controllers;

public class UserController {
	/*
	private UserService userService;

	@GetMapping("/users")
	public List<UserForm> getUsers() {
		return userService.getUsers();
	}

	@GetMapping("/users/{id}")
	public UserForm getUser(@PathVariable long id) {
		return userService.getUser(id);
	}

	@PostMapping("/users")
	public UserForm addUser(@RequestBody UserForm userForm) {
		return userService.addUser(userForm);
	}

	@PutMapping("/users/{id}")
	public UserForm updateUser(@RequestBody UserForm userForm, @PathVariable long id) {
		return userService.updateUser(userForm, id);
	}

	@DeleteMapping("/users/{id}")
	public void deleteUser(@PathVariable long id) {
		userService.deleteUser(id);
	}


	 */


}
