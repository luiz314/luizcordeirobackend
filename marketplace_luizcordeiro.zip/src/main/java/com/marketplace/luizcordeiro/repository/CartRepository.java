package com.marketplace.luizcordeiro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marketplace.luizcordeiro.models.cart.CartImpl;

public interface CartRepository extends JpaRepository<CartImpl, Long>{

}
