package com.marketplace.luizcordeiro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marketplace.luizcordeiro.models.item.CartItemImpl;

public interface CartItemRepository extends JpaRepository<CartItemImpl, Long>{

}
