package com.marketplace.luizcordeiro.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.marketplace.luizcordeiro.models.product.ProductImpl;

public interface ProductRepository extends JpaRepository<ProductImpl, Long>{

	
	@Query
	public List<ProductImpl> findByDeletedFalse();
	
	
	@Query
	public List<ProductImpl> findByName(String name);
}
