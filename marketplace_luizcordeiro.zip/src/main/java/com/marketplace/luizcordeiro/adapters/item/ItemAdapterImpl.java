package com.marketplace.luizcordeiro.adapters.item;

import com.marketplace.luizcordeiro.exceptions.EmptyFieldException;
import com.marketplace.luizcordeiro.exceptions.NotFoundException;
import com.marketplace.luizcordeiro.forms.CartItemForm;
import com.marketplace.luizcordeiro.models.item.CartItemImpl;
import com.marketplace.luizcordeiro.services.item.IItemService;
import com.marketplace.luizcordeiro.services.item.ItemServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ItemAdapterImpl implements IItemAdapter {

	@Autowired
	private ItemServiceImpl itemService;
	
	public CartItemImpl getById(Long itemId) throws NotFoundException, EmptyFieldException {
		return itemService.getById(itemId);
	}
	
	public CartItemImpl updateItem(Long cartId, CartItemForm itemForm) throws NotFoundException, EmptyFieldException {
		return itemService.updateItem(cartId, itemForm);
	}

	@Override
	public void deleteItem(Long itemId) throws NotFoundException, EmptyFieldException {
		itemService.deleteItem(itemId);
	}

	@Override public CartItemImpl saveItem(CartItemForm itemForm) throws EmptyFieldException, NotFoundException {

		return itemService.saveItem(itemForm);
	}

	@Override
	public List<CartItemImpl> findAll() {
		return itemService.findAll();
	}

}
