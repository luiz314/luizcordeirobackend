package com.marketplace.luizcordeiro.adapters.item;

import com.marketplace.luizcordeiro.models.item.IItem;

public interface IItemAdapter extends IItem {

}
