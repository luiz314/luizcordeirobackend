package com.marketplace.luizcordeiro.adapters.product;

import com.marketplace.luizcordeiro.models.product.IProduct;

public interface IProductAdapter extends IProduct {

}
