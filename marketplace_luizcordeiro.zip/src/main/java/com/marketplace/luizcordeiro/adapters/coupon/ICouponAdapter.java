package com.marketplace.luizcordeiro.adapters.coupon;

import com.marketplace.luizcordeiro.models.coupon.ICoupon;

public interface ICouponAdapter extends ICoupon {
}
