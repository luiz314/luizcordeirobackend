package com.marketplace.luizcordeiro.adapters.cart;

import com.marketplace.luizcordeiro.models.cart.ICart;

public interface ICartAdapter extends ICart {

}
