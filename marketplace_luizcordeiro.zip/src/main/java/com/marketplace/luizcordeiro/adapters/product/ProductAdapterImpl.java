package com.marketplace.luizcordeiro.adapters.product;

import java.util.List;

import com.marketplace.luizcordeiro.services.product.ProductServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;

import com.marketplace.luizcordeiro.exceptions.EmptyFieldException;
import com.marketplace.luizcordeiro.exceptions.ProductNotFoundException;
import com.marketplace.luizcordeiro.forms.ProductForm;
import com.marketplace.luizcordeiro.models.product.ProductImpl;
import org.springframework.stereotype.Component;

@Component
public class ProductAdapterImpl implements IProductAdapter {

	@Autowired
	private ProductServiceImpl productServiceImpl;
	
	@Override
	public List<ProductImpl> getAllProducts() {
		return productServiceImpl.getAllProducts();
	}

	@Override
	public List<ProductImpl> getActivesProducts() {
		return productServiceImpl.getActivesProducts();
	}

	@Override
	public ProductImpl getById(Long productId) throws ProductNotFoundException, EmptyFieldException {
		return productServiceImpl.getById(productId);
	}

	@Override
	public ProductImpl saveProduct(ProductForm product) throws EmptyFieldException {
		return productServiceImpl.saveProduct(product);
	}

	@Override
	public ProductImpl updateProduct(ProductForm product) throws ProductNotFoundException, EmptyFieldException {
		return productServiceImpl.updateProduct(product);
	}

	@Override
	public void deleteProduct(Long productId) throws ProductNotFoundException, EmptyFieldException {
		productServiceImpl.deleteProduct(productId);
	}

	@Override
	public void reactivateProduct(Long productId) throws ProductNotFoundException, EmptyFieldException {
		productServiceImpl.reactivateProduct(productId);
	}

}
