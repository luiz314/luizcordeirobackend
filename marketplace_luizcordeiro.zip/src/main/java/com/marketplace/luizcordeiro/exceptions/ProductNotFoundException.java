package com.marketplace.luizcordeiro.exceptions;

public class ProductNotFoundException extends NotFoundException{

	public ProductNotFoundException() {
		super("Product");
	}
	
}
