package com.marketplace.luizcordeiro.exceptions;

public class CartItemNotFoundException extends NotFoundException{

	public CartItemNotFoundException() {
		super("Cart Item");
	}

	
	
}
