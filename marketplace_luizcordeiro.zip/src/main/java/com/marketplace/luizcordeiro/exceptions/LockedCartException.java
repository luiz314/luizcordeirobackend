package com.marketplace.luizcordeiro.exceptions;

public class LockedCartException extends Exception {

    public LockedCartException() {
        super("Locked car exception");
    }
}
