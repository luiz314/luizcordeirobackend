package com.marketplace.luizcordeiro.exceptions;

public class CouponNotFoundException extends NotFoundException{
	
	public CouponNotFoundException() {
		super("Coupon");
	}

}
