package com.marketplace.luizcordeiro.exceptions;

public class CartNotFoundException extends NotFoundException{
	
	public CartNotFoundException() {
		super("Cart");
	}

}
