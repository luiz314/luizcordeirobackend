package com.marketplace.luizcordeiro.validators;

public class ValidatorUtil {

	
	public static boolean isNotNull(Object object) {
		return object != null;
	}
	
	public static boolean isNull(Object object) {
		return object == null;
	}
}
