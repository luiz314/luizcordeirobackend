package com.marketplace.luizcordeiro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuizcordeiroApplicationTests {

	@Test
	void contextLoads() {
	}

}
