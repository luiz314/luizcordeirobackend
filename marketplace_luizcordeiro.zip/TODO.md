
<pre>OBS: Create User service</pre>
<img src="pic.png" alt="project-description">

<h1> Cart </h1>
<ol type="1"> 
    <li>
        Not create cart function, the cart must be create automatically
        when the user choses to add a product to the cart
    </li>
    <li>
        The cart shouldn't be saved in postgres database,
        must be in cache until the cart is closed (payed)
        a. Should be delete from cache, when doesn't have any item
    </li>
</ol>

    

    
        

    