Usuario:
    id
    nome,
    email,
    senha,
    data_nascimento


    